## First install all dependencies

yarn
yarn dev (project running on localhost:3000)

## Postgres Setup

install postgres in your computer
set password
hit all commands one by one that I have metioned in database.sql file.
then open db.js file if you set password earlier during installation then add password property in db.js file.
